# EA-PS2342-06B Bridge — Raspberry Pi / Ubuntu LAN Server

Hosts the EA-PS2342-06B TCP bridge on a Raspberry Pi 4 running Ubuntu,
making the power supply accessible at `192.168.1.6:5025` from any device
on the LAN (or via a firewall NAT rule from anywhere on the internet).

---

## Architecture

```
EA-PS2342 USB
     │
     ▼
Raspberry Pi 4  (Ubuntu, /dev/ttyACM0)
     │
     ├── ea_ps2342.py     ← binary protocol driver
     ├── ea_bridge.py     ← TCP/SCPI translation layer
     └── systemd service  ← starts at boot, restarts on crash
     │
     ▼  TCP port 5025
LAN (192.168.1.x)
     │
     ├── EEZ Studio on Windows/macOS/Linux
     ├── Python scripts on any machine
     └── Internet (via firewall NAT → 192.168.1.6:5025)
```

VirtualHere USB Server runs alongside this bridge but must **exclude** the
PS2342 from its device list — they cannot share the same USB device.
See [VirtualHere exclusion](#virtualhere-exclusion) below.

---

## Quick Install (RPi / Ubuntu)

Copy the four files to the RPi, then run the installer:

```bash
# On the RPi — copy files first (scp, USB stick, or git clone)
chmod +x install_rpi.sh
./install_rpi.sh
```

The installer:
1. Installs Python 3 and `pyserial` if not present
2. Adds your user to the `dialout` group (serial port access)
3. Copies bridge files to `~/ea_ps2342/`
4. Auto-detects the serial port (`/dev/ttyACM0` or `/dev/ttyUSB0`)
5. Installs and enables the `ea_ps2342_bridge` systemd service
6. Starts the service immediately

After installation the bridge starts automatically every boot.

---

## Manual Installation (step by step)

### 1. Install Python and pyserial

```bash
sudo apt update
sudo apt install python3 python3-pip
pip3 install pyserial
```

### 2. Serial port access

```bash
sudo usermod -aG dialout $USER
# Log out and back in for the group change to take effect
```

Verify: `ls -l /dev/ttyACM0` should show `crw-rw---- ... dialout`.

### 3. Find the serial port

```bash
# Plug in the PS2342 USB cable, then:
ls /dev/ttyACM*   # most common for PS2342 (CDC-ACM driver)
ls /dev/ttyUSB*   # alternative (FTDI driver on some units)

# Confirm it's the PS2342:
dmesg | tail -20 | grep -i "tty\|usb\|acm"
```

### 4. Copy bridge files

```bash
mkdir -p ~/ea_ps2342
cp ea_ps2342.py ea_bridge.py ~/ea_ps2342/
```

### 5. Test manually before enabling the service

```bash
bash start_bridge.sh
```

Expected output:
```
[Bridge] Connected to /dev/ttyACM0
[Bridge] PS 2342-06B  42 V / 6 A  fw V3.02
[Bridge] Listening on 0.0.0.0:5025
```

Test with netcat from another machine:
```bash
echo "*IDN?" | nc 192.168.1.6 5025
# Should return: EA Elektro-Automatik,PS 2342-06B,12345,V3.02
```

### 6. Install the systemd service

```bash
sudo cp ea_ps2342_bridge.service /etc/systemd/system/
# Edit the service file to confirm paths and serial port:
sudo nano /etc/systemd/system/ea_ps2342_bridge.service

sudo systemctl daemon-reload
sudo systemctl enable ea_ps2342_bridge   # start at boot
sudo systemctl start  ea_ps2342_bridge   # start now
```

---

## Service Management

```bash
# Status
sudo systemctl status ea_ps2342_bridge

# Live log
sudo journalctl -u ea_ps2342_bridge -f

# Last 50 log lines
sudo journalctl -u ea_ps2342_bridge -n 50

# Restart (e.g. after config change)
sudo systemctl restart ea_ps2342_bridge

# Stop
sudo systemctl stop ea_ps2342_bridge

# Disable auto-start at boot
sudo systemctl disable ea_ps2342_bridge
```

---

## VirtualHere Exclusion

VirtualHere and the Python bridge both need exclusive access to the USB device.
They cannot run simultaneously on the same device.

Exclude the PS2342 from VirtualHere by editing the VH server config:

```ini
# /etc/virtualhere/config.ini  (or wherever your VH config lives)
[General]
# Add the PS2342 USB VID:PID to the exclusion list
# PS2000B VID=0964, PID=0064 (verify with: lsusb)
ExcludeDevices=0964:0064
```

Then restart VirtualHere:
```bash
sudo systemctl restart virtualhere   # or whatever your VH service is called
```

Verify the device is excluded:
```bash
lsusb | grep -i "0964"   # find the PS2342
# VH should no longer list it in its web UI
```

---

## EEZ Studio Connection

In EEZ Studio: **Add instrument → EA-PS2342-06B Bridge → Ethernet**
- Address: `192.168.1.6`  (or your RPi's actual IP)
- Port: `5025`

Find the RPi's IP: `hostname -I` or check your router's DHCP table.

For a stable address, assign a static IP or DHCP reservation to the RPi's
MAC address in your router.

---

## Internet Access (optional firewall NAT)

To access the bridge from outside your LAN, add a port-forward rule on your
router/firewall:

```
External port 5025 (TCP) → 192.168.1.6:5025
```

**Security note:** The bridge has no authentication. Anyone who can reach
port 5025 can control the power supply. Consider:
- Restricting source IPs in the firewall rule
- Running the bridge inside a VPN (WireGuard on the RPi is lightweight)
- Using a non-standard external port to reduce automated scanning

---

## Differences from the Local Workstation Version

| | Workstation (Windows) | RPi Server |
|---|---|---|
| Serial port | `COM3` | `/dev/ttyACM0` |
| Bind address | `127.0.0.1` (local only) | `0.0.0.0` (all interfaces) |
| Startup | `start_bridge.bat` (manual) | systemd (automatic at boot) |
| Restart on crash | no | yes (5 s delay) |
| Tracking support | yes | yes |
| Python files | same | same |
| EEZ IEXT | same zip | same zip |

The Python files (`ea_ps2342.py`, `ea_bridge.py`) are **identical** between
both deployments — only the startup method and bind address differ.

---

## Troubleshooting

**Service fails to start — serial port not found**
```bash
sudo journalctl -u ea_ps2342_bridge -n 20
# Look for: "No such file or directory: '/dev/ttyACM0'"
# Fix: edit the ExecStart line in the service unit, change the --serial argument
sudo systemctl edit --full ea_ps2342_bridge
sudo systemctl restart ea_ps2342_bridge
```

**Permission denied on serial port**
```bash
sudo journalctl -u ea_ps2342_bridge -n 5
# Look for: "PermissionError: [Errno 13] Permission denied"
# Fix: confirm user is in dialout group
groups pi   # replace 'pi' with your username
# If dialout not listed: sudo usermod -aG dialout pi  then reboot
```

**PS2342 shows as VirtualHere device instead of /dev/ttyACM0**
```
The VH server is claiming the device before cdc_acm binds.
Add the device to VH ExcludeDevices as described above.
```

**EEZ connects but *IDN? times out**
```
The bridge is running but not responding fast enough.
Check: sudo journalctl -u ea_ps2342_bridge -f
Common cause: previous crashed session left the serial port in a bad state.
Fix: sudo systemctl restart ea_ps2342_bridge
```
