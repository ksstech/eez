# RPi4 Weekly Backup to Proton Drive

Automated weekly backup of the complete RPi server configuration to
Proton Drive, using `rclone` with the native Proton Drive backend.
Runs every Sunday at 02:00, retains 6 snapshots (~6 weeks).

---

## What gets backed up

Rather than listing individual applications, the script copies the **entire
`/etc/` directory tree** using `rsync`. This means every application config
is captured automatically — nothing needs updating when new software is installed.

| Item | Source | Notes |
|------|--------|-------|
| EA-PS2342 bridge scripts | `~/ea_ps2342/` | |
| VirtualHere binary + config | `/usr/bin/vhusbd*` + `config.ini` | Checks `/usr/bin`, `/root`, `/usr/local/bin` |
| **All of `/etc/`** | `/etc/` (rsync, filtered) | Covers everything — see below |
| User dotfiles | `~/.config/`, `~/.ssh/`, `~/.bashrc`, etc. | Midnight Commander, rclone, SSH keys |
| systemd units | `/etc/systemd/system/*.service` / `*.timer` | All custom units |
| Cron jobs | `/etc/cron.*`, user crontabs | |
| Installed package lists | `dpkg --get-selections`, `apt-mark showmanual`, `pip3 list` | Full rebuild reference |
| Backup metadata | hostname, date, kernel, disk, webmin version | |

### Why `/etc/` covers everything

| Application | Config location | Backed up? |
|-------------|----------------|-----------|
| Webmin | `/etc/webmin/` | ✓ automatically |
| SSH server | `/etc/ssh/` | ✓ automatically |
| UFW firewall | `/etc/ufw/` | ✓ automatically |
| fail2ban | `/etc/fail2ban/` | ✓ automatically |
| Midnight Commander | `~/.config/mc/` | ✓ via dotfiles |
| apt sources | `/etc/apt/sources.list.d/` | ✓ automatically |
| sudoers | `/etc/sudoers.d/` | ✓ automatically |
| Any future tool | `/etc/<toolname>/` | ✓ automatically |

> **Not backed up:** OS binaries, apt package cache, kernel modules.
> The `dpkg --get-selections` output reinstalls all packages on a fresh Ubuntu
> image in one command.

---

## Proton Drive layout

```
Proton Drive/
  └── RPi4-Backups/
        ├── 2026-06-08/          ← most recent
        │     ├── ea_ps2342/
        │     ├── virtualhere/
        │     ├── systemd/
        │     ├── etc/
        │     ├── home_config/
        │     ├── cron/
        │     ├── packages/
        │     ├── rclone.conf
        │     └── backup_info.txt
        ├── 2026-06-01/
        └── ... (6 total, oldest auto-deleted)
```

---

## One-time setup — rclone Proton Drive authentication

### Step 1 — Install rclone on the RPi

**Do not use `apt install rclone`.** Ubuntu 22.04 ships v1.53 and Ubuntu 24.04
ships v1.60 — both predate the Proton Drive backend (added in v1.65). The
`install_backup.sh` script handles this correctly. To install manually:

```bash
curl -fsSL https://downloads.rclone.org/rclone-current-linux-arm64.deb \
     -o /tmp/rclone.deb
sudo dpkg -i /tmp/rclone.deb
rm /tmp/rclone.deb
rclone --version                          # must show v1.65 or higher
rclone config providers | grep -i proton  # confirm backend present
```

### Step 2 — Configure the Proton Drive remote on the RPi

Proton Drive uses **username and password directly** — no browser or OAuth
token is needed. The entire setup happens on the RPi terminal:

```bash
rclone config
```

Answer each prompt exactly as follows:

| Prompt | Answer |
|--------|--------|
| `e/n/d/r/c/s/q>` | `n` — new remote |
| `name>` | `protondrive` |
| `Storage>` | `protondrive` |
| `user>` | your Proton email address |
| `y/g/n>` (password) | `y` — then type your Proton password |
| `2fa>` | your current 6-digit authenticator code (if 2FA enabled) |
| `otp_secret_key y/g/n>` | **`n`** — leave blank (see warning below) |
| `Advanced config? y/n>` | `n` |
| `y/e/d>` | `y` — keep this remote |
| `e/n/d/r/c/s/q>` | `q` — quit |

> ⚠ **`otp_secret_key` warning:** Answer **`n`** here. This field expects the
> raw base32 seed string from when you first set up 2FA (the secret behind the
> QR code) — not your 6-digit login code. Entering anything else causes a
> "Decoding of secret as base32 failed" error on every connection.
> Answering `n` is correct — rclone uses the `2fa>` code you entered above
> for the initial login, then caches the session and never asks for 2FA again.

> ⚠ **`rclone authorize` does NOT work for Proton Drive.** That command is
> only for OAuth2 backends (Google Drive, OneDrive, Dropbox). Do not run it.

### Step 3 — Verify the connection

```bash
rclone lsf protondrive:
```

Your Proton Drive folders will be listed (or empty output on a new drive —
both mean success). After this first successful connection, rclone caches the
session tokens in `~/.config/rclone/rclone.conf` and runs fully unattended
from this point on — no 2FA prompt on future runs.

### Step 4 — Run the installer

```bash
chmod +x install_backup.sh
sudo bash install_backup.sh
```

---

## Installation

The installer handles everything from step 2 onwards:

```bash
chmod +x install_backup.sh
sudo bash install_backup.sh
```

It will:
1. Install rclone from the official ARM64 deb (not apt)
2. Verify the `protondrive` remote is configured and reachable
3. Create the `RPi4-Backups` folder on Proton Drive
4. Install `rpi_backup.sh` to `/home/pi/ea_backup/`
5. Install and enable the systemd service and timer

---

## Managing the backup

```bash
# Check when the next backup will run
systemctl list-timers rpi_backup.timer

# Run a backup immediately (for testing)
sudo systemctl start rpi_backup.service

# Watch live output
sudo journalctl -u rpi_backup.service -f

# View log file
sudo tail -50 /var/log/rpi_backup.log

# Last backup status
sudo systemctl status rpi_backup.service

# Disable automatic backups
sudo systemctl disable rpi_backup.timer
```

---

## Changing retention

Edit `/home/pi/ea_backup/rpi_backup.sh` and change:

```bash
KEEP_COPIES=6   # 4 = ~1 month, 6 = ~6 weeks, 8 = ~2 months
```

---

## Restoring from backup

```bash
# List available snapshots
rclone lsf protondrive:RPi4-Backups/ --dirs-only

# Restore bridge scripts
rclone copy "protondrive:RPi4-Backups/2026-06-08/ea_ps2342" ~/ea_ps2342/
sudo systemctl restart ea_ps2342_bridge

# Restore VirtualHere config
rclone copy "protondrive:RPi4-Backups/2026-06-08/virtualhere/config.ini" /usr/bin/
sudo systemctl restart virtualhere

# Full rebuild on a new RPi — reinstall all packages
rclone copy "protondrive:RPi4-Backups/$(rclone lsf protondrive:RPi4-Backups/ \
    --dirs-only | sort | tail -1)" ~/restore/
sudo dpkg --set-selections < ~/restore/packages/dpkg_selections.txt
sudo apt-get dselect-upgrade -y
```

---

## Troubleshooting

**protondrive not listed during `rclone config`**
```bash
rclone --version   # must be v1.65 or higher
# If too old:
curl -fsSL https://downloads.rclone.org/rclone-current-linux-arm64.deb \
     -o /tmp/rclone.deb && sudo dpkg -i /tmp/rclone.deb && rm /tmp/rclone.deb
```

**"Decoding of secret as base32 failed"**
```bash
# You entered something in otp_secret_key — delete the remote and redo
rclone config
# → d (delete) → select protondrive → n (new) → answer n to otp_secret_key
```

**Code=2028 "unusual activity" block**
```bash
# Proton has temporarily blocked the IP due to repeated failed logins.
# Test if the block has lifted:
curl -s https://drive-api.proton.me/auth/v4 -o /dev/null -w "%{http_code}"
# 405 = block lifted, safe to retry rclone config
# 422 = still blocked — wait 30-60 minutes or appeal at proton.me/support/appeal-abuse
```

**Timer not firing**
```bash
systemctl list-timers rpi_backup.timer
sudo systemctl enable --now rpi_backup.timer
```

**Proton session expired (rare — tokens last weeks/months)**
```bash
# Delete and redo the remote — same process as initial setup
rclone config
# → d → protondrive → n → new config with fresh 2FA code
```
