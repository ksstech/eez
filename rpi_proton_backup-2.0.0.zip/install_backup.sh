#!/usr/bin/env bash
# =============================================================================
#  install_backup.sh  —  One-shot installer for the RPi Proton Drive backup
#
#  Run this AFTER completing the rclone Proton Drive auth (see README_Backup.md)
# =============================================================================
set -euo pipefail

INSTALL_DIR="/home/pi/ea_backup"
BACKUP_USER="${SUDO_USER:-pi}"
HOME_DIR="/home/${BACKUP_USER}"

echo ""
echo "══════════════════════════════════════════════════"
echo "  RPi Proton Drive Backup — Installer"
echo "══════════════════════════════════════════════════"
echo ""

# ── 1. Install rclone from official ARM64 deb ────────────────────────────────
# The apt version on Ubuntu 22.04 is v1.53 and on 24.04 is v1.60 — both
# predate the Proton Drive backend (added in v1.65).
# We download the current ARM64 deb directly from rclone's CDN and install
# via dpkg — the most reliable method for a headless RPi4 on Ubuntu.
echo "[1/5] Installing rclone (current ARM64 release from rclone.org)..."

# Remove any old apt-installed rclone first to avoid PATH conflicts
if dpkg -l rclone 2>/dev/null | grep -q "^ii"; then
    echo "  Removing old apt rclone ($(rclone --version 2>/dev/null | head -1))..."
    sudo apt-get remove -y rclone -qq
fi

# Install unzip if needed (dpkg handles the .deb directly — no unzip needed)
sudo apt-get install -y -qq curl

# Download current stable ARM64 deb
DEB_URL="https://downloads.rclone.org/rclone-current-linux-arm64.deb"
DEB_FILE="/tmp/rclone-current-linux-arm64.deb"
echo "  Downloading ${DEB_URL}..."
curl -fsSL "$DEB_URL" -o "$DEB_FILE" || {
    echo "  ERROR: Download failed. Check network connectivity."
    exit 1
}

# Install
sudo dpkg -i "$DEB_FILE"
rm -f "$DEB_FILE"

RCLONE_VER=$(rclone --version 2>/dev/null | head -1 | awk '{print $2}')
echo "  rclone ${RCLONE_VER}: installed"

# Verify Proton Drive backend is present (requires v1.65+)
if ! rclone config providers 2>/dev/null | grep -qi "protondrive"; then
    echo ""
    echo "  ERROR: protondrive backend not found in this rclone build."
    echo "  Got version: ${RCLONE_VER}  (need v1.65 or higher)"
    echo "  The ARM64 deb from rclone.org should always include it."
    echo "  Check: https://downloads.rclone.org/rclone-current-linux-arm64.deb"
    exit 1
fi
echo "  Proton Drive backend: present"

# ── 2. Verify Proton Drive remote is configured ───────────────────────────────
echo "[2/5] Checking rclone Proton Drive remote..."
RCLONE_CONF="${HOME_DIR}/.config/rclone/rclone.conf"

if ! rclone listremotes --config "$RCLONE_CONF" 2>/dev/null | grep -q "^protondrive:"; then
    echo ""
    echo "  ⚠  Proton Drive remote not configured yet."
    echo ""
    echo "  Complete these steps BEFORE re-running this installer:"
    echo ""
    echo "  ┌─── On this RPi (no browser needed) ─────────────────────────────┐"
    echo "  │  rclone config                                                   │"
    echo "  │  → n  (new remote)                                               │"
    echo "  │  → name: protondrive                                             │"
    echo "  │  → type: protondrive  (or choose from list)                      │"
    echo "  │  → enter your Proton email and password when prompted            │"
    echo "  │  → Use auto config? → n  (headless — no browser on RPi)          │"
    echo "  └──────────────────────────────────────────────────────────────────┘"
    echo ""
    echo "  ┌─── On your Windows/Mac (has a browser) ─────────────────────────┐"
    echo "  │  rclone authorize \"protondrive\"                                 │"
    echo "  │  → browser opens → log in → copy the token printed              │"
    echo "  │  → paste token back into the RPi terminal                       │"
    echo "  └──────────────────────────────────────────────────────────────────┘"
    echo ""
    echo "  Then re-run: sudo bash install_backup.sh"
    exit 1
fi
echo "  protondrive remote: found ✓"

# Test connectivity
echo "  Testing Proton Drive connectivity..."
if rclone lsf --config "$RCLONE_CONF" "protondrive:" --max-depth 1 >/dev/null 2>&1; then
    echo "  Connection: OK ✓"
else
    echo "  ⚠  Could not list Proton Drive. Check credentials and network."
    echo "     Try manually: rclone lsf protondrive:"
    exit 1
fi

# ── 3. Create backup folder on Proton Drive ───────────────────────────────────
echo "[3/5] Creating remote folder RPi4-Backups on Proton Drive..."
rclone mkdir --config "$RCLONE_CONF" "protondrive:RPi4-Backups" 2>/dev/null || true
echo "  RPi4-Backups: OK"

# ── 4. Install backup script ──────────────────────────────────────────────────
echo "[4/5] Installing backup script to ${INSTALL_DIR}..."
sudo mkdir -p "$INSTALL_DIR"
sudo cp rpi_backup.sh "$INSTALL_DIR/"
sudo chmod +x "${INSTALL_DIR}/rpi_backup.sh"
sudo chown root:root "${INSTALL_DIR}/rpi_backup.sh"

# Patch the BACKUP_USER in the script to match actual user
sudo sed -i "s|^BACKUP_USER=.*|BACKUP_USER=\"${BACKUP_USER}\"|" \
    "${INSTALL_DIR}/rpi_backup.sh"
echo "  Script installed: OK"

# ── 5. Install and enable systemd timer ──────────────────────────────────────
echo "[5/5] Installing systemd service and timer..."

# Patch service unit with correct script path and user
sed "s|/home/pi/ea_backup|${INSTALL_DIR}|g" rpi_backup.service \
    | sudo tee /etc/systemd/system/rpi_backup.service > /dev/null
sudo cp rpi_backup.timer /etc/systemd/system/rpi_backup.timer

sudo systemctl daemon-reload
sudo systemctl enable rpi_backup.timer
sudo systemctl start  rpi_backup.timer   # start the timer (not the job)
echo "  Timer enabled: OK"

# ── Summary ───────────────────────────────────────────────────────────────────
NEXT=$(systemctl list-timers rpi_backup.timer --no-legend 2>/dev/null \
    | awk '{print $1, $2}' | head -1)

echo ""
echo "══════════════════════════════════════════════════"
echo "  Installation complete"
echo ""
echo "  Schedule : every Sunday at 02:00"
echo "  Next run : ${NEXT:-see: systemctl list-timers rpi_backup.timer}"
echo "  Retention: 6 weekly snapshots on Proton Drive"
echo "  Remote   : protondrive:RPi4-Backups/YYYY-MM-DD/"
echo "  Log file : /var/log/rpi_backup.log"
echo "  Log live : sudo journalctl -u rpi_backup.service -f"
echo ""
echo "  To run a backup NOW (test):"
echo "    sudo systemctl start rpi_backup.service"
echo "    sudo journalctl -u rpi_backup.service -f"
echo "══════════════════════════════════════════════════"
echo ""
