#!/usr/bin/env bash
# =============================================================================
#  rpi_backup.sh  —  Weekly RPi server backup to Proton Drive
#
#  Backs up:
#    - EA-PS2342 bridge scripts    ~/ea_ps2342/
#    - VirtualHere binary + config /usr/bin/vhusbd* + config.ini locations
#    - systemd service units       /etc/systemd/system/
#    - cron jobs                   /etc/cron* + user crontabs
#    - network config              /etc/network* /etc/netplan* /etc/hosts
#    - apt package list            (for full rebuild reference)
#    - rclone config               ~/.config/rclone/rclone.conf
#
#  Rotation: keeps KEEP_COPIES weekly snapshots on Proton Drive.
#  Logs:     journalctl -u rpi_backup.service
#
#  First-time setup: see README_Backup.md
# =============================================================================
set -euo pipefail

# ── Configuration ─────────────────────────────────────────────────────────────
RCLONE_REMOTE="protondrive"          # name given during rclone config
REMOTE_BASE="RPi4-Backups"          # top-level folder on Proton Drive
KEEP_COPIES=6                        # number of weekly backups to retain (6 = ~6 weeks)
BACKUP_USER="${SUDO_USER:-pi}"       # user whose home dir to back up
HOME_DIR="/home/${BACKUP_USER}"
STAGING="/tmp/rpi_backup_staging"   # local temp dir, wiped each run
LOG_TAG="rpi_backup"

# ── Logging helpers ───────────────────────────────────────────────────────────
log()  { echo "[$(date '+%Y-%m-%d %H:%M:%S')]  $*" | tee -a "$LOGFILE" ; }
fail() { log "ERROR: $*" ; exit 1 ; }

DATESTAMP=$(date '+%Y-%m-%d')
LOGFILE="/var/log/rpi_backup.log"
touch "$LOGFILE" && chmod 640 "$LOGFILE"

log "======================================================="
log " RPi backup starting  —  snapshot: ${DATESTAMP}"
log "======================================================="

# ── Sanity checks ─────────────────────────────────────────────────────────────
command -v rclone >/dev/null || fail "rclone not found — run install_backup.sh first"
rclone listremotes | grep -q "^${RCLONE_REMOTE}:" \
    || fail "rclone remote '${RCLONE_REMOTE}' not configured — see README_Backup.md"

# ── Stage all backup content ──────────────────────────────────────────────────
rm -rf "$STAGING"
mkdir -p \
    "$STAGING/ea_ps2342" \
    "$STAGING/virtualhere" \
    "$STAGING/systemd" \
    "$STAGING/etc" \
    "$STAGING/home_config" \
    "$STAGING/cron" \
    "$STAGING/packages"

log "Staging files..."

# ── EA bridge scripts ─────────────────────────────────────────────────────────
if [ -d "${HOME_DIR}/ea_ps2342" ]; then
    cp -r "${HOME_DIR}/ea_ps2342/"* "$STAGING/ea_ps2342/" 2>/dev/null || true
    log "  ea_ps2342: OK"
else
    log "  ea_ps2342: not found, skipping"
fi

# ── VirtualHere ───────────────────────────────────────────────────────────────
# Binary (for version reference) and config.ini.
# Config lives next to the binary OR in /root when running as a daemon.
for VH_DIR in /usr/bin /usr/local/bin /root /home/${BACKUP_USER}; do
    if ls "${VH_DIR}"/vhusbd* 2>/dev/null | head -1 | grep -q vhusbd; then
        cp "${VH_DIR}"/vhusbd* "$STAGING/virtualhere/" 2>/dev/null || true
        log "  VH binary: found in ${VH_DIR}"
    fi
    if [ -f "${VH_DIR}/config.ini" ]; then
        SAFE="${VH_DIR//\//_}"
        cp "${VH_DIR}/config.ini" "$STAGING/virtualhere/config${SAFE}.ini"
        log "  VH config.ini: found in ${VH_DIR}"
    fi
done
[ -f /etc/systemd/system/virtualhere.service ] \
    && cp /etc/systemd/system/virtualhere.service "$STAGING/virtualhere/"
log "  VirtualHere: staged"

# ── systemd units ─────────────────────────────────────────────────────────────
cp /etc/systemd/system/*.service "$STAGING/systemd/" 2>/dev/null || true
cp /etc/systemd/system/*.timer   "$STAGING/systemd/" 2>/dev/null || true
log "  systemd units: OK"

# ── /etc — all application configs ───────────────────────────────────────────
# Copy the entire /etc tree, excluding large/binary/transient paths.
# This captures Webmin (/etc/webmin), SSH (/etc/ssh), fail2ban, ufw,
# apt sources, sudoers, and anything else installed on the server —
# without needing to know what is installed in advance.
rsync -a --relative \
    --exclude="/etc/alternatives" \
    --exclude="/etc/apt/cache" \
    --exclude="/etc/apt/lists" \
    --exclude="/etc/blkid.tab" \
    --exclude="/etc/blkid.tab.old" \
    --exclude="/etc/mtab" \
    --exclude="/etc/ld.so.cache" \
    --exclude="/etc/udev/hwdb.bin" \
    --exclude="/etc/.pwd.lock" \
    /etc "$STAGING/etc/" 2>/dev/null || true
log "  /etc (all configs): OK ($(du -sh "$STAGING/etc" 2>/dev/null | cut -f1))"

# ── User home — dotfiles and app configs ──────────────────────────────────────
# ~/.config/mc/      Midnight Commander panels, options, hotlist
# ~/.config/rclone/  rclone auth tokens
# ~/.ssh/            SSH keys and known_hosts
# ~/.bashrc etc.     Shell config
for DOT in .config .ssh .bashrc .bash_profile .profile .vimrc .nanorc; do
    SRC="${HOME_DIR}/${DOT}"
    if [ -e "$SRC" ]; then
        cp -r "$SRC" "$STAGING/home_config/" 2>/dev/null || true
    fi
done
log "  User dotfiles (~/.config, ~/.ssh, etc.): OK"

# ── Cron jobs ─────────────────────────────────────────────────────────────────
for CRONITEM in /etc/cron.d /etc/cron.daily /etc/cron.weekly /etc/crontab; do
    [ -e "$CRONITEM" ] && cp -r "$CRONITEM" "$STAGING/cron/" 2>/dev/null || true
done
if crontab -u "${BACKUP_USER}" -l >/dev/null 2>&1; then
    crontab -u "${BACKUP_USER}" -l \
        > "$STAGING/cron/user_${BACKUP_USER}_crontab" 2>/dev/null || true
fi
log "  Cron jobs: OK"

# ── Installed package lists ───────────────────────────────────────────────────
dpkg --get-selections  > "$STAGING/packages/dpkg_selections.txt" 2>/dev/null || true
apt-mark showmanual    > "$STAGING/packages/apt_manual.txt"      2>/dev/null || true
dpkg -l                > "$STAGING/packages/dpkg_full_list.txt"  2>/dev/null || true
pip3 list 2>/dev/null  > "$STAGING/packages/pip3_list.txt"       2>/dev/null || true
log "  Package lists: OK"

# Backup metadata
{
    echo "hostname:    $(hostname)"
    echo "date:        $(date -u '+%Y-%m-%d %H:%M:%S UTC')"
    echo "kernel:      $(uname -r)"
    echo "uptime:      $(uptime -p)"
    echo "disk_root:   $(df -h / | awk 'NR==2{print $3"/"$2" ("$5" used)"}')"
    echo "rclone:      $(rclone --version | head -1)"
} > "$STAGING/backup_info.txt"
log "  Metadata: OK"

# ── Upload to Proton Drive ────────────────────────────────────────────────────
REMOTE_DEST="${RCLONE_REMOTE}:${REMOTE_BASE}/${DATESTAMP}"
log "Uploading to ${REMOTE_DEST}..."

rclone copy "$STAGING" "${REMOTE_DEST}" \
    --log-level INFO \
    --log-file "$LOGFILE" \
    --transfers 4 \
    --checkers 8 \
    --retries 3 \
    --retries-sleep 10s

log "Upload complete."

# ── Rotate old backups — keep KEEP_COPIES most recent ─────────────────────────
log "Checking retention (keep ${KEEP_COPIES} copies)..."

# List all dated backup folders on Proton Drive, sorted oldest-first
EXISTING=$(rclone lsf "${RCLONE_REMOTE}:${REMOTE_BASE}/" \
    --dirs-only 2>/dev/null \
    | grep -E '^[0-9]{4}-[0-9]{2}-[0-9]{2}/$' \
    | sed 's|/$||' \
    | sort)

TOTAL=$(echo "$EXISTING" | grep -c . || true)
DELETE_COUNT=$(( TOTAL - KEEP_COPIES ))

if [ "$DELETE_COUNT" -gt 0 ]; then
    TO_DELETE=$(echo "$EXISTING" | head -n "$DELETE_COUNT")
    log "Removing ${DELETE_COUNT} old snapshot(s):"
    while IFS= read -r snap; do
        log "  deleting: ${snap}"
        rclone purge "${RCLONE_REMOTE}:${REMOTE_BASE}/${snap}" \
            --log-level INFO --log-file "$LOGFILE"
    done <<< "$TO_DELETE"
else
    log "No old snapshots to remove (${TOTAL}/${KEEP_COPIES} slots used)."
fi

# ── Cleanup ───────────────────────────────────────────────────────────────────
rm -rf "$STAGING"
log "Staging directory removed."

log "======================================================="
log " Backup complete: ${DATESTAMP}"
log " Remote: ${REMOTE_DEST}"
log " Snapshots retained: $(( TOTAL > KEEP_COPIES ? KEEP_COPIES : TOTAL ))"
log "======================================================="
